// Headless generator: opens index.html in a real browser (via Playwright),
// fills in today's AED prices, lets the page's own JS read yesterday's row +
// live FX rates + submit today's row, then saves the canvas as
// output/gold-price-card.png.
//
// This assumes SHEET_CSV_URL / FORM_ACTION_URL / ENTRY_IDS are already
// filled in inside index.html (see SETUP_GUIDE.md Part 1, step 4).
//
// Run locally with:
//   AED_24=529.75 AED_22=490.75 AED_21=470.50 AED_18=403.25 AED_14=314.50 node scripts/generate.mjs

import { chromium } from 'playwright';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const indexPath = path.join(__dirname, '..', 'index.html');
const outDir = path.join(__dirname, '..', 'output');
fs.mkdirSync(outDir, { recursive: true });

const prices = {
  '24': process.env.AED_24,
  '22': process.env.AED_22,
  '21': process.env.AED_21,
  '18': process.env.AED_18,
  '14': process.env.AED_14,
};
for (const [k, v] of Object.entries(prices)) {
  if (!v) { console.error(`Missing AED_${k} environment variable / repo secret.`); process.exit(1); }
}

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1200, height: 1500 } });

await page.goto('file://' + indexPath);
await page.fill('#aed24', prices['24']);
await page.fill('#aed22', prices['22']);
await page.fill('#aed21', prices['21']);
await page.fill('#aed18', prices['18']);
await page.fill('#aed14', prices['14']);
await page.click('#goBtn');

// Wait for the status line to say success or error
await page.waitForFunction(() => {
  const el = document.getElementById('status');
  return el && (el.classList.contains('ok') || el.classList.contains('err'));
}, { timeout: 30000 });

const statusText = await page.textContent('#status');
const isOk = await page.evaluate(() => document.getElementById('status').classList.contains('ok'));
if (!isOk) {
  console.error('Card generation failed:', statusText);
  await browser.close();
  process.exit(1);
}

const canvas = await page.$('#card');
await canvas.screenshot({ path: path.join(outDir, 'gold-price-card.png') });

console.log('Saved output/gold-price-card.png —', statusText);
await browser.close();
